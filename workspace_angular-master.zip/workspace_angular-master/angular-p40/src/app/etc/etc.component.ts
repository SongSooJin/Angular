import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-etc',
  templateUrl: './etc.component.html',
  styleUrls: ['./etc.component.css']
})
export class EtcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
