import { MyClickDirective } from './my-click.directive';

describe('MyClickDirective', () => {
  it('should create an instance', () => {
    const directive = new MyClickDirective();
    expect(directive).toBeTruthy();
  });
});
