import { Injectable } from '@angular/core';

@Injectable()
export class Engine {
  public name: string = "엔진";
}
