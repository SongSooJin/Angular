export class Kpop {
  id: number;
  name: string;
  image: string;
}
