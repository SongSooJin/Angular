import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoreTestComponent } from './core-test.component';

describe('CoreTestComponent', () => {
  let component: CoreTestComponent;
  let fixture: ComponentFixture<CoreTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoreTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoreTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
