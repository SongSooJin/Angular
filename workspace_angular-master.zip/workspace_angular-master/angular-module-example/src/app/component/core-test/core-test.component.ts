import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-core-test',
  templateUrl: './core-test.component.html',
  styleUrls: ['./core-test.component.css']
})
export class CoreTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
