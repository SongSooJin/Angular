import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-event-directive',
  templateUrl: './custom-event-directive.component.html',
  styleUrls: ['./custom-event-directive.component.css']
})
export class CustomEventDirectiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
