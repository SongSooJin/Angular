import { MyHiddenDirective } from './my-hidden.directive';

describe('MyHiddenDirective', () => {
  it('should create an instance', () => {
    const directive = new MyHiddenDirective();
    expect(directive).toBeTruthy();
  });
});
