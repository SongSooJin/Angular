import { Injectable } from '@angular/core';

@Injectable()
export class SuperPowerEngine {
  public name: string = "슈퍼엔진";
  public description = '세계 최고의 성능을 자랑하는 슈퍼엔진';
}
